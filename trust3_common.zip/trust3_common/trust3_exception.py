class Trust3Exception(Exception):
    def __init__(self, message: str = None):
        self.message = message
        super().__init__(self.message)


class AuditEventQueueFullException(Trust3Exception):
    def __init__(self, message: str = None):
        super().__init__(message)


class DiskFullException(Trust3Exception):
    def __init__(self, message: str = None):
        super().__init__(message)
